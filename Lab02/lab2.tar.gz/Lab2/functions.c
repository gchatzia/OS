// functions.c
#include <stdio.h>
#include "functions.h"

// Function definitions
void greet() {
    printf("Hello from functions.c!\n");
}

int add(int a, int b) {
    return a + b;
}
